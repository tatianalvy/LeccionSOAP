/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package controlador;

import vista.Login;

/**
 *
 * @author Asus
 */
public class MainClassGeneral {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Login login = new Login();
        Controlador_Login contrLogin= new Controlador_Login(login);

    }
    
}
