/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vista;

import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import ws.Operaciones;
import ws.Operaciones_Service;

/**
 *
 * @author miche
 */
public class RegistrarUsuario extends javax.swing.JFrame {

    Operaciones_Service service = new Operaciones_Service();
    Operaciones cws = service.getOperacionesPort();

    /**
     * Creates new form RegistrarUsuario
     */
    public RegistrarUsuario() {
        initComponents();
        setLocationRelativeTo(null);
    }

    private void limpiarCampos() {
        txtnombre.setText("");
        txtapellido.setText("");
        txtdni.setText("");
        txtcelular.setText("");
        txtcorreo.setText("");
        txtusuario.setText("");
        txtcontra.setText("");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtnombre = new javax.swing.JTextField();
        txtapellido = new javax.swing.JTextField();
        txtcelular = new javax.swing.JTextField();
        txtcorreo = new javax.swing.JTextField();
        txtusuario = new javax.swing.JTextField();
        txtcontra = new javax.swing.JTextField();
        btnRegistrar = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        txtdni = new javax.swing.JTextField();
        btnlimpiar = new javax.swing.JButton();
        jLabel8 = new javax.swing.JLabel();
        cmbRol = new javax.swing.JComboBox<>();
        jLabel9 = new javax.swing.JLabel();
        checkCrear = new javax.swing.JCheckBox();
        checkEditar = new javax.swing.JCheckBox();
        checkEliminar = new javax.swing.JCheckBox();
        checkVisualizar = new javax.swing.JCheckBox();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(237, 237, 247));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel1.setText("Nombre:");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 170, -1, -1));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel2.setText("Apellido:");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 230, -1, -1));

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel3.setText("Celular:");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 360, -1, -1));

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel4.setText("Correo:");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 420, -1, -1));

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel5.setText("Usuario:");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 480, -1, -1));

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel6.setText("Contraseña:");
        jLabel6.setToolTipText("");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 540, -1, -1));

        txtnombre.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jPanel1.add(txtnombre, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 170, 256, -1));

        txtapellido.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jPanel1.add(txtapellido, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 230, 256, -1));

        txtcelular.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jPanel1.add(txtcelular, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 360, 256, -1));

        txtcorreo.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jPanel1.add(txtcorreo, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 420, 256, -1));

        txtusuario.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jPanel1.add(txtusuario, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 470, 256, -1));

        txtcontra.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jPanel1.add(txtcontra, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 530, 256, -1));

        btnRegistrar.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnRegistrar.setText("Registrar Usuario");
        btnRegistrar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRegistrarActionPerformed(evt);
            }
        });
        jPanel1.add(btnRegistrar, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 851, -1, 40));

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel7.setText("DNI:");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 300, -1, -1));

        txtdni.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        jPanel1.add(txtdni, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 300, 256, -1));

        btnlimpiar.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        btnlimpiar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/limpieza-de-datos.png"))); // NOI18N
        btnlimpiar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnlimpiarActionPerformed(evt);
            }
        });
        jPanel1.add(btnlimpiar, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 850, 80, 40));

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        jLabel8.setText("Registro Usuario");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 50, -1, -1));

        cmbRol.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        cmbRol.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Administrador", "Empleado" }));
        jPanel1.add(cmbRol, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 610, 182, -1));

        jLabel9.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel9.setText("Rol:");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 610, -1, -1));

        checkCrear.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        checkCrear.setText("Crear");
        jPanel1.add(checkCrear, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 680, -1, -1));

        checkEditar.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        checkEditar.setText("Editar");
        checkEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkEditarActionPerformed(evt);
            }
        });
        jPanel1.add(checkEditar, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 740, -1, -1));

        checkEliminar.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        checkEliminar.setText("Eliminar");
        checkEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkEliminarActionPerformed(evt);
            }
        });
        jPanel1.add(checkEliminar, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 680, -1, -1));

        checkVisualizar.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        checkVisualizar.setText("Visualizar");
        checkVisualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkVisualizarActionPerformed(evt);
            }
        });
        jPanel1.add(checkVisualizar, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 740, -1, -1));

        jLabel10.setFont(new java.awt.Font("Times New Roman", 1, 18)); // NOI18N
        jLabel10.setText("Seleccionar Competencias:");
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 680, -1, -1));

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img/cliente.png"))); // NOI18N
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 30, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 726, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 939, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnRegistrarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRegistrarActionPerformed
        String nombre = txtnombre.getText();
        String apellido = txtapellido.getText();
        String dni = txtdni.getText();  // Ajusta el nombre del campo según tu formulario
        String celular = txtcelular.getText();
        String correo = txtcorreo.getText();
        String user = txtusuario.getText();
        String password = txtcontra.getText();

        // Validar que no falten campos obligatorios (debes ajustar según tu formulario)
        if (nombre.isEmpty() || apellido.isEmpty() || dni.isEmpty() || celular.isEmpty() || correo.isEmpty() || user.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Llamar al método del servicio web para registrar el usuario
        boolean registroExitoso = cws.registrarUsuario(nombre, apellido, dni, celular, correo, user, password);

        // Manejar el resultado del registro
        if (registroExitoso) {
            JOptionPane.showMessageDialog(this, "Usuario registrado exitosamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);

            Login ventlogin = new Login();
            ventlogin.setVisible(true);
            this.dispose();

        } else {
            JOptionPane.showMessageDialog(this, "Error al registrar el usuario", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_btnRegistrarActionPerformed

    private void btnlimpiarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnlimpiarActionPerformed
        limpiarCampos();
    }//GEN-LAST:event_btnlimpiarActionPerformed

    private void checkEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkEliminarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_checkEliminarActionPerformed

    private void checkEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkEditarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_checkEditarActionPerformed

    private void checkVisualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkVisualizarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_checkVisualizarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnRegistrar;
    private javax.swing.JButton btnlimpiar;
    private javax.swing.JCheckBox checkCrear;
    private javax.swing.JCheckBox checkEditar;
    private javax.swing.JCheckBox checkEliminar;
    private javax.swing.JCheckBox checkVisualizar;
    private javax.swing.JComboBox<String> cmbRol;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JTextField txtapellido;
    private javax.swing.JTextField txtcelular;
    private javax.swing.JTextField txtcontra;
    private javax.swing.JTextField txtcorreo;
    private javax.swing.JTextField txtdni;
    private javax.swing.JTextField txtnombre;
    private javax.swing.JTextField txtusuario;
    // End of variables declaration//GEN-END:variables
}
